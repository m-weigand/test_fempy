def CRMod():
    print('Calling CRMod')
